from flask import Flask, render_template, request, jsonify
import RPi.GPIO as GPIO
GPIO.setwarnings(False)

import threading

app = Flask(__name__)

GPIO.setmode(GPIO.BCM)
LED_PIN = 18
GPIO.setup(LED_PIN, GPIO.OUT)

# Shared variable to store messages from terminal
terminal_message = ""

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/send_data', methods=['POST'])
def send_data():
    data = request.json
    message = data.get('message')
    print(f"Received from dashboard: {message}")

    if message.lower() == "on":
        GPIO.output(LED_PIN, GPIO.HIGH)
    elif message.lower() == "off":
        GPIO.output(LED_PIN, GPIO.LOW)

    return jsonify({"status": "received", "message": message})

@app.route('/get_terminal_data')
def get_terminal_data():
    global terminal_message
    return jsonify({"terminal_message": terminal_message})

def listen_to_terminal():
    global terminal_message
    while True:
        user_input = input("Enter message for dashboard: ")
        terminal_message = user_input  # Update shared variable

# Start thread to listen to terminal
threading.Thread(target=listen_to_terminal, daemon=True).start()

if __name__ == '__main__':
    try:
        app.run(host='0.0.0.0', port=5000)
    finally:
        GPIO.cleanup()
