from flask import Flask, request, render_template, redirect
import json
import os

app = Flask(__name__)

command_file = "command.txt"
data_file = "data.json"

@app.route("/")
def dashboard():
    # Read command
    command = "STOP"
    if os.path.exists(command_file):
        with open(command_file, "r") as f:
            command = f.read().strip()

    # Read sensor data
    temperature, humidity = "--", "--"
    if os.path.exists(data_file):
        with open(data_file, "r") as f:
            try:
                data = json.load(f)
                if command == "OK":
                    temperature = data.get("temperature", "--")
                    humidity = data.get("humidity", "--")
            except json.JSONDecodeError:
                pass

    return render_template("dashboard.html", temperature=temperature, humidity=humidity, command=command)

@app.route("/command", methods=["POST"])
def update_command():
    cmd = request.form.get("cmd", "STOP")
    with open(command_file, "w") as f:
        f.write(cmd)
    return redirect("/")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
