import Adafruit_DHT
import time
import json

SENSOR = Adafruit_DHT.DHT11
PIN = 4  # GPIO pin

while True:
    humidity, temperature = Adafruit_DHT.read_retry(SENSOR, PIN)
    
    if humidity is not None and temperature is not None:
        print(f"Temp: {temperature:.1f}°C  Humidity: {humidity:.1f}%")

        with open("data.json", "w") as f:
            json.dump({"temperature": temperature, "humidity": humidity}, f)
    else:
        print("Failed to get reading. Trying again...")

    time.sleep(2)
